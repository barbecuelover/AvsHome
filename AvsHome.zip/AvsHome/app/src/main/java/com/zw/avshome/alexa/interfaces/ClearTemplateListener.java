package com.zw.avshome.alexa.interfaces;

public interface ClearTemplateListener {
    void onClearTemplate();
}
