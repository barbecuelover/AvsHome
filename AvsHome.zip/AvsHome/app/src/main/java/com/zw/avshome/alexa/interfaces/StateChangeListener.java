package com.zw.avshome.alexa.interfaces;

public interface StateChangeListener {
    void setStateChangeListener(Object data);
}
