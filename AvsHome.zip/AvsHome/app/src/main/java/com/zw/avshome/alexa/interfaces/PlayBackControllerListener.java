package com.zw.avshome.alexa.interfaces;

public interface PlayBackControllerListener {
    void setPlayBackControllerListener(String string);
}
