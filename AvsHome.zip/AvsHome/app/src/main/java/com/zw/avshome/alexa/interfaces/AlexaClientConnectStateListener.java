package com.zw.avshome.alexa.interfaces;

public interface AlexaClientConnectStateListener {
    void setAlexaClientConnectStateListener(Object state);
}