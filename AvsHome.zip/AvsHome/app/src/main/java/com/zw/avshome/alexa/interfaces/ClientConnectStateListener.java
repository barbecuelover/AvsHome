package com.zw.avshome.alexa.interfaces;

public interface ClientConnectStateListener {
    void setClientConnectStateListener(Object data);
}
