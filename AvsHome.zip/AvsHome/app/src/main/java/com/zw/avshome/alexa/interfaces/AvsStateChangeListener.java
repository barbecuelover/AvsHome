package com.zw.avshome.alexa.interfaces;

public interface AvsStateChangeListener {
    void setAvsStateChangeListener(Object state);
}
