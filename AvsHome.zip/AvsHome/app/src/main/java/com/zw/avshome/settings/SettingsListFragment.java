package com.zw.avshome.settings;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.zw.avshome.R;
import com.zw.avshome.home.base.ParentFragment;
import com.zw.avshome.settings.bean.SettingItem;

import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class SettingsListFragment extends ParentFragment {

    private RecyclerView recyclerView;
    private List<SettingItem> list = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_settings_list, null, false);
        return view;
    }

    @Override
    public void initView() {
        recyclerView = view.findViewById(R.id.recycler_view_settings_list_fg);
        GridLayoutManager gridlayoutManager = new GridLayoutManager(context, 2);
        gridlayoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(gridlayoutManager);


    }

    @Override
    public void initData() {

        list.clear();
        SettingItem alexaItem = new SettingItem("Alexa",R.mipmap.setting_item_alexa);
        SettingItem themeItem= new SettingItem("Theme",R.mipmap.setting_item_theme);
        SettingItem settingsItem = new SettingItem("Settings",R.mipmap.setting_item_settings);
        SettingItem d5FirmwareItem = new SettingItem("D5 FW",R.mipmap.setting_item_d5_update);
        list.add(alexaItem);
        list.add(themeItem);
        list.add(settingsItem);
        list.add(d5FirmwareItem);


    }

    @Override
    public void initEvent() {

    }
}
