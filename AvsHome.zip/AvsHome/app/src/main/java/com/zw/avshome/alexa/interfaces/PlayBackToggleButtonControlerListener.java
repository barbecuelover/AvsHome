package com.zw.avshome.alexa.interfaces;

public interface PlayBackToggleButtonControlerListener {
    void setPlayBackToggleButtonControlerListener(String string, boolean bl);
}
