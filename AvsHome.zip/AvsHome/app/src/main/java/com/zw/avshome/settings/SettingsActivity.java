package com.zw.avshome.settings;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.zw.avshome.R;
import com.zw.avshome.home.base.ParentActivity;
import com.zw.avshome.settings.views.BlurringView;

import androidx.cardview.widget.CardView;

public class SettingsActivity extends ParentActivity {

    private BlurringView mBgBlurView;
    private CardView mBgCardView1, mBgCardView2, mBgCardView3, mSettingsCardViewContent;
    private CardView mSettingsLeftBtn, mSettingsRightBtn;
    private FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        initView();
        initData();
        initEvent();
    }

    @Override
    public void initView() {

        mBgBlurView = findViewById(R.id.settings_bg_blur_view);
        mBgCardView1 = findViewById(R.id.settings_bg_card_view_1);
        mBgCardView2 = findViewById(R.id.settings_bg_card_view_2);
        mBgCardView3 = findViewById(R.id.settings_bg_card_view_3);
        mSettingsLeftBtn = findViewById(R.id.settings_left_btn);
        mSettingsRightBtn = findViewById(R.id.settings_right_btn);
        mSettingsCardViewContent = findViewById(R.id.settings_card_view_content);
    }

    @Override
    public void initData() {

        fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        //fragmentTransaction.replace(R.id.settings_fragment_container, hubSettingListFragment);
        fragmentTransaction.commit();

    }

    @Override
    public void initEvent() {

    }

    @Override
    public Activity getActivity() {
        return this;
    }
}
